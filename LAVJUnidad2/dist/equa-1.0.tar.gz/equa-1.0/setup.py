from setuptools import setup
setup(
    name='equa',
    version='1.0',
    description='examen',
    author='angel velazquez',
    author_email='luisangelvelazquezjimenez@gmail.com',
    url='headfirtslabs.com',
    py_modules=['equa'],
    )